#!/bin/bash
set -euo pipefail

readonly OUTPUT=Equ

cp ../EM/minimized.gro .
GRO=../EM/*.gro
[ ! -f *.top ] && cp ../Build/*.top .
[ ! -f *.ndx ] && cp ../Build/*.ndx .
NDX=so2_gromacs.ndx
# cp ../so2_gromacs.ndx .
grompp -f NVT.mdp -c ${GRO} -p so2.top -n ${NDX} -o ${OUTPUT}.tpr

# mdrun -nt 1 -v -s topol.tpr -o nvt.trr -e nvt.edr -g nvt.log
mdrun -nt 1 -v -deffnm ${OUTPUT}