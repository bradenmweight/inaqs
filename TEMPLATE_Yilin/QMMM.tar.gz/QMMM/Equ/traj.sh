## After we get the results of the trajectory calculation, we can use the following script to convert the trajectory into .xtc format:
## also can use gmx command to center, analyze the traj. 

### Reminder: In GROMACS, all command-line tools are invoked through a unified front-end program called gmx, with the syntax gmx <command> [options].
### For example, to run the gmx grompp command, you would type gmx grompp [options].
### But here, only the command is used, without the gmx prefix.

## easier version for the small system

## output trajectory file
trjconv -s *.tpr -f *.trr -o output.xtc

## center the trajectory
trjconv -s Equ.tpr -f output.xtc -o centered.xtc -center
##### When prompted, select the appropriate group to center and output things

## large system needs to consider them:
# ## re-wrap the molecules back into the primary box
echo "0" | trjconv -s *.tpr -f centered.xtc -o wrapped.xtc -pbc mol

# ## avoid molecules across periodic boundaries
echo "0" | trjconv -s *.tpr -f wrapped.xtc -o whole.xtc -pbc whole

rm  -rf wrapped.xtc centered.xtc




