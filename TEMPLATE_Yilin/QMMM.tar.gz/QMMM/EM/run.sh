#!/bin/bash
set -euo pipefail # Exit on error, unset variable, or pipe failure
export GMX_MAXBACKUP=-1

readonly NAME=minimized
readonly DIR="../Build/"

# [ ! -f gifs_config.ini ] && cp ../gifs_config.ini .

# rm -rf GQSH GQSH.sav mdout.mdp minimized.{edr,log,tpr,trr}
grompp -f minim.mdp -c ${DIR}*solvated.gro -p ${DIR}*.top -n ${DIR}*.ndx -o ${NAME}.tpr
mdrun -nt 1 -v -deffnm ${NAME}

echo
echo "Your minimized structure should now be in ${NAME}.gro"
