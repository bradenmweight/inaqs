#!/bin/bash
#SBATCH -p debug
#SBATCH -x bhd0005
#SBATCH -J INAQS2
#SBATCH -o outputrun_all.slurm
#SBATCH -t 1:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH --mem 5GB


# rm -rf /local_scratch/$SLURM_JOB_ID/*
# rm -rf *.trr,tpr
# rm -rf *.hdf5, cs.dat
# rm -r GQSH ## remove old GQSH directory

#### LOAD THESE AT COMMAND LINE BEFORE RUNNING THIS JOB ####
module purge
module load circ libgd/2.2.5 glibc/2.29 
module load hdf5/1.8.17/b1 armadillo/8.500.0
module load blas/0.3.20/b1 cmake/3.30.2/b1
module unload gcc
module load intel/2020.4 gcc/11.2.0/b1

source /gpfs/fs2/scratch/phuo_lab/INAQS_QMMM_NAMD_QCHEM_GROMACS/inaqs/gromacs-4.6.5/install/bin/GMXRC.bash

export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1

#QCHEM Environment
QCHEM_HOME=/scratch/phuo_lab/Program/Qchem
export QC=$QCHEM_HOME
source $QCHEM_HOME/qcenv.sh
ulimit -s unlimited
export QCSCRATCH="/local_scratch/$SLURM_JOB_ID/QCSCRATCH"
export QCLOCALSCR="/local_scratch/$SLURM_JOB_ID/QCLOCALSCR"
mkdir -p $QCSCRATCH
mkdir -p $QCLOCALSCR
bash /scratch/yguo52/inaqs/examples/so2_whole/EM/run.sh

