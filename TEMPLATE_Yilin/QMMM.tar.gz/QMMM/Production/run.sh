#!/bin/bash



for i in {5..205}; do
    mkdir -p frames_with_vel$i # create directory for each frame
    cd frames_with_vel$i
    cp ../../Equ/frames/frames_with_vel$i.gro frames_with_vel$i.gro 
    cp ../../Equ/*.top  .
    cp ../../Equ/*.ndx  .
    cp ../nve.mdp nve.mdp 
    cp ../sub.sh  .
    cp ../inaqs_config.dat .
    
    sbatch sub.sh -p reserved --reservation=phuo_20250312  # submit the job
    # echo "0" | trjconv -s *.tpr -f *.trr -o output.xtc
    cd ..
done
echo "All frames have been processed."






